package accessmodifiers;

public class privateconstructors {

	class A{  
		private A(){}//private constructor  
		
			void msg(){System.out.println("Hello java");}  
			}  
			public class Simple{  
			 public void main(String args[])
			 {
				 
				 //public static void main(String args[]) 
				 /** because we can not create the instance of the private 
				                                             constructor outside the class **/			  
				 A obj=new A();//Compile Time Error  
				 obj.msg();
			 }  
			}  

}
