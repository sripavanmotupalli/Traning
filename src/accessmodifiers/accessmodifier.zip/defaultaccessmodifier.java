package accessmodifiers;

public class defaultaccessmodifier {
		//save by A.java  
		//package pack;  
		class A{
	
	  void msg(){System.out.println("Hello");}  
		}  
		//save by B.java  
	//	package accessmodifiers;  
	//	import pack.*;  
		class B{  
		  public void main(String args[]){  
			  
			  /*    public static void main(String args[]){ in default no need of using static because we dont explicity 
			  declare for class field and method*/
			  
			  
		   A obj = new A();//Compile Time Error  
		   obj.msg();//Compile Time Error  
		  }  
		}

	
}
