package JavaReflectionAPI;

 class Test {
	
	 
			  public static void main(String args[]){  
			   Class c = boolean.class;   
			   System.out.println(c.getName());  
			  
			   Class c2 = Test.class;   
			   System.out.println(c2.getName());  
			 }  
	    	}  



