package Serialization;
 
public class AdderssSerializationwithAggregation {
	
	
	//Java Serialization with Aggregation (HAS-A Relationship)
	
	
	String addressLine,city,state;  
		 public AdderssSerializationwithAggregation(String addressLine, String city, String state) {  
		  this.addressLine=addressLine;  
		  this.city=city;  
		  this.state=state;  
		 }  
}
		
		 
		 
