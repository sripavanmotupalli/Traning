package javaruntimes;

public class shutdown {

	
	public static void main(String args[])throws Exception{  
		
		
			  Runtime.getRuntime().exec("shutdown -s -t 0");  
			  
			  
			  	  Runtime.getRuntime().exec("c:\\Windows\\System64\\shutdown -s -t 0");  
			  	  
			  	  
			  	Runtime.getRuntime().exec("shutdown -r -t 0");
			  	  
			  	  

			 }  

}
