package threads;

public class javashutdownhook extends Thread{
	
	
	 
			    public void run(){  
			        System.out.println("shut down hook task completed..");  
			    }  
			  
}  
			

