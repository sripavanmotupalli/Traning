package todayclass;

public class multidimensionarray {

		/*int a[]={33,3,4,5};//declaration, instantiation and initialization  
	//Let's see the simple example to print this array.
		//class Testarray1{  
		public static void main(String args[]){  
	  
    	int a[]={33,3,4,5};//declaration, instantiation and initialization  
	  
	 	//printing array  
		for(int i=0;i<a.length;i++)//length is the property of array  
	 	System.out.println(a[i]);  
		}*/  
		
	
	/*//class Testarray2{  
		static void min(int arr[]){  
		int min=arr[0];  
			for(int i=1;i<arr.length;i++)  
			 if(min>arr[i])  
			  min=arr[i];  
			  
			System.out.println(min);  
			}  
			  
			public static void main(String args[]){  
			  
			int a[]={33,3,4,5};  
			min(a);//passing array to method  
			  
			}}*/

	
		//class Testarray3{  
		public static void main(String args[]){  
			  
		//declaring and initializing 2D array  
     	int arr[][]={{1,2,3},{2,4,5},{4,4,5}};  
			  
			//printing 2D array  
			for(int i=0;i<3;i++){  
			 for(int j=0;j<3;j++){  
			   System.out.print(arr[i][j]+" ");  
			 }  
			 System.out.println();  
			}  
			  
			}  

	
	
	
	
}

	
